# Script to update the model rotation pool
# Run via: bash scripts/update-config.sh
hermes config set credential_pool_strategies.gemini.models '["gemini-3.6-flash", "gemini-3.5-flash", "gemini-2.5-flash", "gemini-2.5-pro", "gemini-3.1-flash", "gemini-3.1-flash-lite", "gemini-3.1-pro-preview", "gemma-4-26b-a4b-it", "gemma-4-31b-it"]'
