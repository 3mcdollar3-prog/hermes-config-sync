---
name: model-cycler
description: "Rotates the active Hermes model to exhaust specific rate limits."
---

# Model Cycler

This skill automates switching between high-throughput Gemini models to maximize API quota efficiency.

## Model Rotation Strategies
When facing rate limits on models like Gemini 2.5 Flash, implement rotation strategies:
- Use `model-cycler` to rotate active models periodically.
- For more advanced key-rotation, refer to `references/gemini-model-rotation.md` in the `hermes-agent` skill, which details code-level rotation of models per API key.

## Usage

```bash
# Switch to the next model in the rotation list
hermes skills run model-cycler
```

## Pitfalls & Troubleshooting
- **API Key Visibility:** `hermes auth list` only displays credentials explicitly added via `hermes auth add`. Keys defined via environment variables (`.env`) will rotate correctly but will *not* appear in the `hermes auth list` report.
- **Rotation Configuration:** Ensure your rotation strategy is defined in `config.yaml` under `credential_pool_strategies`. The rotation engine automatically switches models/keys upon 429 (Resource Exhausted) errors.
- **Interactive Auth Failures:** If `hermes auth add` fails in a non-interactive shell (often due to `getpass` errors), add keys manually to `~/.hermes/.env` using the `KEY_NAME=value` format.
- **Verification:** Use `hermes status` or `hermes auth list` to confirm that the agent is detecting your key pool, but rely on your application logs to verify the actual rotation flow.
- **Testing Model Health:** To verify individual models and keys, use `hermes chat -m <model> -q "Hi" -Q`. If successful, the exit code is 0; otherwise, inspect the error message.

## Rotation List (Synchronized with Hermes Config)
1. gemma-4-26b-a4b-it
2. gemma-4-31b-it
3. gemini-2.5-flash
4. gemini-2.5-pro
5. gemini-3.1-flash
6. gemini-3.1-flash-lite
7. gemini-3.1-pro-preview

## Implementation
This skill uses `hermes config set` to define a rotation list in `credential_pool_strategies`, which allows the Hermes core engine to natively rotate models on rate limits (429) without needing external scripts or gateway restarts.

## Configuration (Native Engine Integration)
Ensure your `~/.hermes/config.yaml` includes:

```yaml
credential_pool_strategies:
  gemini:
    rotation: round_robin
    models:
      - gemini-3.6-flash
      - gemini-3.5-flash
      - gemini-2.5-flash
      - gemini-2.5-pro
      - gemini-3.1-flash
      - gemini-3.1-flash-lite
      - gemini-3.1-pro-preview
      - gemma-4-26b-a4b-it
      - gemma-4-31b-it

agent:
  api_max_retries: 5
```
