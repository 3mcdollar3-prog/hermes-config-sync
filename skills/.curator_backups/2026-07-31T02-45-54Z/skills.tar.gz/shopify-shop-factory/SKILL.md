---
name: shopify-shop-factory
description: "Manages the creation and basic setup of Shopify stores and apps."
---

# Shopify Shop Factory

This skill provides functions to automate the creation of Shopify stores and the initial setup of associated apps.

## Functions

### create_shop

Creates a new Shopify development store and a basic app using the Shopify CLI.

**Parameters**:

*   `org_id` (str): Your Shopify Partner Organization ID.
*   `app_name` (str, optional): Name for the new Shopify app. Defaults to a generated name.
*   `template` (str, optional): Shopify app template to use. Defaults to "none".
*   `package_manager` (str, optional): Package manager to use. Defaults to "npm".

**Returns**:

*   A dictionary containing information about the created app and store (e.g., app name, store URL, store admin URL).

**Pitfalls**:

*   Shopify CLI authentication: Ensure the CLI is logged in to your partner account.
*   Interactive prompts: `shopify app init` can be interactive. Flags should minimize this, but explicit handling might be needed.
*   Rate limits: While less likely for initial creation, be mindful of API rate limits for subsequent operations.

## Data Templates

- `templates/products.csv`: Standardized CSV structure for Shopify product imports. Always use this format to ensure valid imports.

## Troubleshooting & Workflow

- Always ensure you are authenticated first: `shopify auth logout && shopify auth login`
- List your organizations if the ID is unknown: `shopify organization list`
- Use the correct flag: `shopify app init --organization-id <id>` (do NOT use `--org`).
- Non-interactive creation: use `--template none` and `--package-manager npm` to avoid prompts.
- If `shopify app init` hangs or times out, use background processes with `notify_on_complete: true`.
- For bulk product imports, prepare a CSV matching `templates/products.csv`.


## Example Usage

```bash
# Check organization ID first
shopify organization list

# Create the app
shopify app init --name <name> --organization-id <id> --template none --package-manager npm
```
