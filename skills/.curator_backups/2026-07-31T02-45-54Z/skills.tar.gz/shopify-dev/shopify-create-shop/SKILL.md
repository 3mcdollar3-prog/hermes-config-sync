---
name: shopify-create-shop
description: "Scaffold a new Shopify app and development store automatically."
---

# Shopify Create Shop

This skill automates the initialization of a Shopify app using the Shopify CLI.

## Usage
`hermes skills run shopify-create-shop --app-name <name>`

## Logic
1. Runs `shopify app init` with non-interactive flags.
2. Uses the Partner Organization ID `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`.
3. Sets up a clean development store environment.

## Script
```bash
#!/bin/bash
# Path: scripts/init-shop.sh
APP_NAME=${1:-"shop-factory-$(date +%s)"}
ORG_ID="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"

shopify app init \
  --name "$APP_NAME" \
  --organization-id "$ORG_ID" \
  --template none \
  --package-manager npm \
  --reset
```
