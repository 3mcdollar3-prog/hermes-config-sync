#!/bin/bash
APP_NAME=${1:-"shop-factory-$(date +%s)"}
ORG_ID="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"

echo "Creating Shopify App: $APP_NAME"
shopify app init \
  --name "$APP_NAME" \
  --organization-id "$ORG_ID" \
  --template none \
  --package-manager npm
