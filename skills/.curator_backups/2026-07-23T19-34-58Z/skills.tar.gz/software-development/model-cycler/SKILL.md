---
name: model-cycler
description: "Rotates the active Hermes model to exhaust specific rate limits."
---

# Model Cycler

This skill automates switching between high-throughput Gemini models to maximize API quota efficiency.

## Usage

```bash
# Switch to the next model in the rotation list
hermes skills run model-cycler
```

## Rotation List (Synchronized with Hermes Config)
1. gemma-4-26b-a4b-it
2. gemma-4-31b-it
3. gemini-2.5-flash
4. gemini-2.5-pro
5. gemini-3.1-flash
6. gemini-3.1-flash-lite
7. gemini-3.1-pro-preview

## Implementation
This skill uses `hermes config set` to define a rotation list in `credential_pool_strategies`, which allows the Hermes core engine to natively rotate models on rate limits (429) without needing external scripts or gateway restarts.

## Configuration (Native Engine Integration)
Ensure your `~/.hermes/config.yaml` includes:

```yaml
credential_pool_strategies:
  gemini:
    rotation: round_robin
    models:
      - gemma-4-26b-a4b-it
      - gemma-4-31b-it
      - gemini-2.5-flash
      - gemini-2.5-pro
      - gemini-3.1-flash
      - gemini-3.1-flash-lite
      - gemini-3.1-pro-preview

agent:
  api_max_retries: 5
```
