#!/bin/bash
# Wrapper script for intelligent model rotation with cooldown and health tracking
python3 /home/mcdollar3/.hermes/scripts/smart_rotate.py "$@"
