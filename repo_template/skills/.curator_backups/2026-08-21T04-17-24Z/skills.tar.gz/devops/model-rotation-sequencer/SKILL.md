---
name: model-rotation-sequencer
description: Strategy to switch from round-robin to a multi-key, sequence-based rotation for model capacity.
---
# Model Rotation Sequencer: API Key + Model Sequential Strategy

This workflow transitions the Hermes Agent from a basic `round_robin` model cycle to a **nested loop sequence** (Model 1-9 per API Key, then rotate Key, then repeat Model 1-9).

## The Strategy
- **Current Problem:** `round_robin` is an "array-of-models" approach. It doesn't track keys, leading to hotspots on single keys.
- **Desired Strategy:** A `key-first, model-sequence` approach.
  1. For Key 1: Cycle through Models 1 through 9.
  2. Once all models are exhausted on Key 1, switch to Key 2.
  3. Cycle through Models 1 through 9.
  4. Repeat until Keys are exhausted.

## Implementation Details
- **API Keys Managed:** 14 Google API keys are currently pooled.
- **Model Sequence:** The rotation script `/home/mcdollar3/hermes-config-sync/rotate_model.py` cycles through 5 models:
  1. `gemma-4-26b-a4b-it`
  2. `gemma-4-31b-it`
  3. `gemini-3.1-flash-lite`
  4. `gemini-2.5-flash`
  5. `gemini-3.5-flash`

Hermes Agent's `config.yaml` natively supports `rotation: round_robin` or `fill_first`. To achieve a strict 1-9 sequence per-key, you should use the `model-cycler` skill which provides an automated script to handle this orchestration.

### Instructions
1. **Remove Existing Strategy:** We will set your `credential_pool_strategies.gemini.rotation` to `fill_first` to prevent the core engine from interfering with our sequential script.
2. **Deploy the Orchestrator:** Use a cron job to call a custom Python script that tracks the current Key-Index and Model-Index in a local state file.

## Setup Commands
```bash
# 1. Update config to allow our custom script control
hermes config set credential_pool_strategies.gemini.rotation "fill_first"

# 2. Deploy the Model Cycler Script
hermes cron create "every 5m" --script "model_cycler_sequential.py"

# 3. Reference: See references/api-key-management.md for adding new keys.
```

## Troubleshooting
- **If models fail (429):** The script checks the HTTP 429 signal and automatically increments the Key-Index, jumping to the next API key in your `~/.hermes/creds` pool.
- **Persistence:** The `current_key_index.json` file ensures that if the agent restarts, it remembers exactly which model/key pair it was testing.
